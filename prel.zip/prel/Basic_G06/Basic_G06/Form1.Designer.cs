﻿namespace Basic_G06
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.a11 = new System.Windows.Forms.TextBox();
            this.a12 = new System.Windows.Forms.TextBox();
            this.a13 = new System.Windows.Forms.TextBox();
            this.a21 = new System.Windows.Forms.TextBox();
            this.a22 = new System.Windows.Forms.TextBox();
            this.a23 = new System.Windows.Forms.TextBox();
            this.a31 = new System.Windows.Forms.TextBox();
            this.a32 = new System.Windows.Forms.TextBox();
            this.a33 = new System.Windows.Forms.TextBox();
            this.b33 = new System.Windows.Forms.TextBox();
            this.b32 = new System.Windows.Forms.TextBox();
            this.b31 = new System.Windows.Forms.TextBox();
            this.b23 = new System.Windows.Forms.TextBox();
            this.b22 = new System.Windows.Forms.TextBox();
            this.b21 = new System.Windows.Forms.TextBox();
            this.b13 = new System.Windows.Forms.TextBox();
            this.b12 = new System.Windows.Forms.TextBox();
            this.b11 = new System.Windows.Forms.TextBox();
            this.c33 = new System.Windows.Forms.TextBox();
            this.c32 = new System.Windows.Forms.TextBox();
            this.c31 = new System.Windows.Forms.TextBox();
            this.c23 = new System.Windows.Forms.TextBox();
            this.c22 = new System.Windows.Forms.TextBox();
            this.c21 = new System.Windows.Forms.TextBox();
            this.c13 = new System.Windows.Forms.TextBox();
            this.c12 = new System.Windows.Forms.TextBox();
            this.c11 = new System.Windows.Forms.TextBox();
            this.x3 = new System.Windows.Forms.Label();
            this.erg3 = new System.Windows.Forms.Label();
            this.Button3 = new System.Windows.Forms.Button();
            this.Button2 = new System.Windows.Forms.Button();
            this.ErgButton = new System.Windows.Forms.Button();
            this.x2 = new System.Windows.Forms.Label();
            this.erg2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // a11
            // 
            this.a11.Location = new System.Drawing.Point(33, 91);
            this.a11.Name = "a11";
            this.a11.Size = new System.Drawing.Size(39, 20);
            this.a11.TabIndex = 0;
            // 
            // a12
            // 
            this.a12.Location = new System.Drawing.Point(78, 91);
            this.a12.Name = "a12";
            this.a12.Size = new System.Drawing.Size(39, 20);
            this.a12.TabIndex = 1;
            // 
            // a13
            // 
            this.a13.Location = new System.Drawing.Point(123, 91);
            this.a13.Name = "a13";
            this.a13.Size = new System.Drawing.Size(39, 20);
            this.a13.TabIndex = 2;
            // 
            // a21
            // 
            this.a21.Location = new System.Drawing.Point(33, 117);
            this.a21.Name = "a21";
            this.a21.Size = new System.Drawing.Size(39, 20);
            this.a21.TabIndex = 3;
            // 
            // a22
            // 
            this.a22.Location = new System.Drawing.Point(78, 117);
            this.a22.Name = "a22";
            this.a22.Size = new System.Drawing.Size(39, 20);
            this.a22.TabIndex = 4;
            // 
            // a23
            // 
            this.a23.Location = new System.Drawing.Point(123, 117);
            this.a23.Name = "a23";
            this.a23.Size = new System.Drawing.Size(39, 20);
            this.a23.TabIndex = 5;
            // 
            // a31
            // 
            this.a31.Location = new System.Drawing.Point(33, 143);
            this.a31.Name = "a31";
            this.a31.Size = new System.Drawing.Size(39, 20);
            this.a31.TabIndex = 6;
            // 
            // a32
            // 
            this.a32.Location = new System.Drawing.Point(78, 143);
            this.a32.Name = "a32";
            this.a32.Size = new System.Drawing.Size(39, 20);
            this.a32.TabIndex = 7;
            // 
            // a33
            // 
            this.a33.Location = new System.Drawing.Point(123, 143);
            this.a33.Name = "a33";
            this.a33.Size = new System.Drawing.Size(39, 20);
            this.a33.TabIndex = 8;
            // 
            // b33
            // 
            this.b33.Location = new System.Drawing.Point(313, 143);
            this.b33.Name = "b33";
            this.b33.Size = new System.Drawing.Size(39, 20);
            this.b33.TabIndex = 17;
            // 
            // b32
            // 
            this.b32.Location = new System.Drawing.Point(268, 143);
            this.b32.Name = "b32";
            this.b32.Size = new System.Drawing.Size(39, 20);
            this.b32.TabIndex = 16;
            // 
            // b31
            // 
            this.b31.Location = new System.Drawing.Point(223, 143);
            this.b31.Name = "b31";
            this.b31.Size = new System.Drawing.Size(39, 20);
            this.b31.TabIndex = 15;
            // 
            // b23
            // 
            this.b23.Location = new System.Drawing.Point(313, 117);
            this.b23.Name = "b23";
            this.b23.Size = new System.Drawing.Size(39, 20);
            this.b23.TabIndex = 14;
            // 
            // b22
            // 
            this.b22.Location = new System.Drawing.Point(268, 117);
            this.b22.Name = "b22";
            this.b22.Size = new System.Drawing.Size(39, 20);
            this.b22.TabIndex = 13;
            // 
            // b21
            // 
            this.b21.Location = new System.Drawing.Point(223, 117);
            this.b21.Name = "b21";
            this.b21.Size = new System.Drawing.Size(39, 20);
            this.b21.TabIndex = 12;
            // 
            // b13
            // 
            this.b13.Location = new System.Drawing.Point(313, 91);
            this.b13.Name = "b13";
            this.b13.Size = new System.Drawing.Size(39, 20);
            this.b13.TabIndex = 11;
            // 
            // b12
            // 
            this.b12.Location = new System.Drawing.Point(268, 91);
            this.b12.Name = "b12";
            this.b12.Size = new System.Drawing.Size(39, 20);
            this.b12.TabIndex = 10;
            // 
            // b11
            // 
            this.b11.Location = new System.Drawing.Point(223, 91);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(39, 20);
            this.b11.TabIndex = 9;
            // 
            // c33
            // 
            this.c33.Location = new System.Drawing.Point(510, 143);
            this.c33.Name = "c33";
            this.c33.Size = new System.Drawing.Size(39, 20);
            this.c33.TabIndex = 26;
            // 
            // c32
            // 
            this.c32.Location = new System.Drawing.Point(465, 143);
            this.c32.Name = "c32";
            this.c32.Size = new System.Drawing.Size(39, 20);
            this.c32.TabIndex = 25;
            // 
            // c31
            // 
            this.c31.Location = new System.Drawing.Point(420, 143);
            this.c31.Name = "c31";
            this.c31.Size = new System.Drawing.Size(39, 20);
            this.c31.TabIndex = 24;
            // 
            // c23
            // 
            this.c23.Location = new System.Drawing.Point(510, 117);
            this.c23.Name = "c23";
            this.c23.Size = new System.Drawing.Size(39, 20);
            this.c23.TabIndex = 23;
            // 
            // c22
            // 
            this.c22.Location = new System.Drawing.Point(465, 117);
            this.c22.Name = "c22";
            this.c22.Size = new System.Drawing.Size(39, 20);
            this.c22.TabIndex = 22;
            // 
            // c21
            // 
            this.c21.Location = new System.Drawing.Point(420, 117);
            this.c21.Name = "c21";
            this.c21.Size = new System.Drawing.Size(39, 20);
            this.c21.TabIndex = 21;
            // 
            // c13
            // 
            this.c13.Location = new System.Drawing.Point(510, 91);
            this.c13.Name = "c13";
            this.c13.Size = new System.Drawing.Size(39, 20);
            this.c13.TabIndex = 20;
            // 
            // c12
            // 
            this.c12.Location = new System.Drawing.Point(465, 91);
            this.c12.Name = "c12";
            this.c12.Size = new System.Drawing.Size(39, 20);
            this.c12.TabIndex = 19;
            // 
            // c11
            // 
            this.c11.Location = new System.Drawing.Point(420, 91);
            this.c11.Name = "c11";
            this.c11.Size = new System.Drawing.Size(39, 20);
            this.c11.TabIndex = 18;
            // 
            // x3
            // 
            this.x3.AutoSize = true;
            this.x3.Location = new System.Drawing.Point(185, 120);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(12, 13);
            this.x3.TabIndex = 27;
            this.x3.Text = "x";
            // 
            // erg3
            // 
            this.erg3.AutoSize = true;
            this.erg3.Location = new System.Drawing.Point(379, 120);
            this.erg3.Name = "erg3";
            this.erg3.Size = new System.Drawing.Size(13, 13);
            this.erg3.TabIndex = 28;
            this.erg3.Text = "=";
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(33, 46);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(75, 23);
            this.Button3.TabIndex = 29;
            this.Button3.Text = "3 x 3";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(33, 17);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(75, 23);
            this.Button2.TabIndex = 30;
            this.Button2.Text = "2 x 2";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // ErgButton
            // 
            this.ErgButton.Location = new System.Drawing.Point(123, 46);
            this.ErgButton.Name = "ErgButton";
            this.ErgButton.Size = new System.Drawing.Size(75, 23);
            this.ErgButton.TabIndex = 31;
            this.ErgButton.Text = "Berechne!";
            this.ErgButton.UseVisualStyleBackColor = true;
            this.ErgButton.Click += new System.EventHandler(this.ErgButton_Click);
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.Location = new System.Drawing.Point(167, 107);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(12, 13);
            this.x2.TabIndex = 32;
            this.x2.Text = "x";
            // 
            // erg2
            // 
            this.erg2.AutoSize = true;
            this.erg2.Location = new System.Drawing.Point(360, 107);
            this.erg2.Name = "erg2";
            this.erg2.Size = new System.Drawing.Size(13, 13);
            this.erg2.TabIndex = 33;
            this.erg2.Text = "=";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(591, 195);
            this.Controls.Add(this.erg2);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.ErgButton);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.erg3);
            this.Controls.Add(this.x3);
            this.Controls.Add(this.c33);
            this.Controls.Add(this.c32);
            this.Controls.Add(this.c31);
            this.Controls.Add(this.c23);
            this.Controls.Add(this.c22);
            this.Controls.Add(this.c21);
            this.Controls.Add(this.c13);
            this.Controls.Add(this.c12);
            this.Controls.Add(this.c11);
            this.Controls.Add(this.b33);
            this.Controls.Add(this.b32);
            this.Controls.Add(this.b31);
            this.Controls.Add(this.b23);
            this.Controls.Add(this.b22);
            this.Controls.Add(this.b21);
            this.Controls.Add(this.b13);
            this.Controls.Add(this.b12);
            this.Controls.Add(this.b11);
            this.Controls.Add(this.a33);
            this.Controls.Add(this.a32);
            this.Controls.Add(this.a31);
            this.Controls.Add(this.a23);
            this.Controls.Add(this.a22);
            this.Controls.Add(this.a21);
            this.Controls.Add(this.a13);
            this.Controls.Add(this.a12);
            this.Controls.Add(this.a11);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox a11;
        private System.Windows.Forms.TextBox a12;
        private System.Windows.Forms.TextBox a13;
        private System.Windows.Forms.TextBox a21;
        private System.Windows.Forms.TextBox a22;
        private System.Windows.Forms.TextBox a23;
        private System.Windows.Forms.TextBox a31;
        private System.Windows.Forms.TextBox a32;
        private System.Windows.Forms.TextBox a33;
        private System.Windows.Forms.TextBox b33;
        private System.Windows.Forms.TextBox b32;
        private System.Windows.Forms.TextBox b31;
        private System.Windows.Forms.TextBox b23;
        private System.Windows.Forms.TextBox b22;
        private System.Windows.Forms.TextBox b21;
        private System.Windows.Forms.TextBox b13;
        private System.Windows.Forms.TextBox b12;
        private System.Windows.Forms.TextBox b11;
        private System.Windows.Forms.TextBox c33;
        private System.Windows.Forms.TextBox c32;
        private System.Windows.Forms.TextBox c31;
        private System.Windows.Forms.TextBox c23;
        private System.Windows.Forms.TextBox c22;
        private System.Windows.Forms.TextBox c21;
        private System.Windows.Forms.TextBox c13;
        private System.Windows.Forms.TextBox c12;
        private System.Windows.Forms.TextBox c11;
        private System.Windows.Forms.Label x3;
        private System.Windows.Forms.Label erg3;
        private System.Windows.Forms.Button Button3;
        private System.Windows.Forms.Button Button2;
        private System.Windows.Forms.Button ErgButton;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label erg2;
    }
}

